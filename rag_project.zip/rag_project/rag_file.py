import os
import pdfplumber
import PyPDF2
import cohere

co = cohere.Client("p8zlCuXpKhFnIHaXOKZnwaOBPrCOsnSUoytpb4qd")

def extract_text_from_pdf(pdf_path):
    with open(pdf_path, 'rb') as file:
        reader = PyPDF2.PdfReader(file)
        text = ""
        for page in range(len(reader.pages)):
            text += reader.pages[page].extract_text()
        return text

pdf_folder = r"/home/khushi/Downloads/rag_project"

documents = []
for filename in os.listdir(pdf_folder):
    if filename.endswith('.pdf'):
        pdf_path = os.path.join(pdf_folder, filename)
        text = extract_text_from_pdf(pdf_path)
        documents.append({"title": filename, "text": text})

message = "Can you tell me about some warnings for washing machine"
message = "Can you tell me about some advantages for washing machine"

response = co.chat_stream(message=message, documents=documents)

for event in response:
    if event.event_type == "text-generation":
        print(event.text, end="")
